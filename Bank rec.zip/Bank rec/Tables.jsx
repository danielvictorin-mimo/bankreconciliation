import { useState } from "react";

// ── Sort icon ────────────────────────────────────────────────────────────────
function SortIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" style={{ flexShrink: 0 }}>
      <path d="M6 2v8M3.5 7.5L6 10l2.5-2.5M3.5 4.5L6 2l2.5 2.5" stroke="#8C8C8B" strokeWidth="1" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

// ── Play circle icon ─────────────────────────────────────────────────────────
function PlayCircleIcon({ color = "#080908", size = 20 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 20 20" fill="none">
      <path d="M10 18.335C14.6024 18.335 18.3333 14.604 18.3333 10.0016C18.3333 5.39926 14.6024 1.66831 10 1.66831C5.39763 1.66831 1.66667 5.39926 1.66667 10.0016C1.66667 14.604 5.39763 18.335 10 18.335Z" stroke={color} strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M7.9165 7.47241C7.9165 7.07467 7.9165 6.87581 7.99962 6.76478C8.07206 6.66803 8.18293 6.6075 8.30349 6.59889C8.44182 6.58901 8.60911 6.69655 8.94368 6.91163L12.8775 9.44052C13.1678 9.62715 13.313 9.72047 13.3631 9.83913C13.4069 9.94281 13.4069 10.0598 13.3631 10.1635C13.313 10.2821 13.1678 10.3755 12.8775 10.5621L8.94368 13.091C8.60911 13.3061 8.44182 13.4136 8.30349 13.4037C8.18293 13.3951 8.07206 13.3346 7.99962 13.2378C7.9165 13.1268 7.9165 12.9279 7.9165 12.5302V7.47241Z" stroke={color} strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

// ── Tr. matching mini-badge (default / unreconciled state) ───────────────────
function TrMatchBadge({ value = "0/0" }) {
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 5,
      background: "#ECECEC", border: "none",
      borderRadius: 4, padding: "2px 8px",
      fontSize: 12, fontWeight: 500, color: "#545453",
    }}>
      <svg width="10" height="10" viewBox="0 0 10 10" fill="none">
        <circle cx="5" cy="5" r="4" stroke="#E9E9EB" strokeWidth="1.5" />
        <path d="M5 1 A4 4 0 0 1 9 5" stroke="#CFCFD1" strokeWidth="1.5" strokeLinecap="round" />
      </svg>
      {value}
    </span>
  );
}

// ── DataTable ────────────────────────────────────────────────────────────────
// A generic, configurable Mimo data table with section title, sortable headers,
// vertical cell borders, hover states, and a footer count.
//
// Props:
//   title         — string: section title rendered inside the table border
//   columns       — array of { key, label, width?, sortable?, align?, render? }
//                   • key: property name on each row object
//                   • label: column header text
//                   • width: CSS grid column width (e.g. "2fr", "1fr", "220px")
//                   • sortable: show sort icon in header (default false)
//                   • align: "left" | "right" (default "left")
//                   • render: fn(value, row, index) → ReactNode for custom cell content
//   rows          — array of row objects keyed by column.key
//   footerLabel   — string: text for the footer row (e.g. "4 bank accounts")
//   onRowClick    — fn(row, index): optional row click handler
export function DataTable({
  title,
  columns = [],
  rows = [],
  footerLabel,
  onRowClick,
}) {
  const [hovered, setHovered] = useState(null);

  const gridTemplate = columns.map(c => c.width || "1fr").join(" ");

  return (
    <div style={{
      background: "#FFFFFF",
      border: "1px solid #E9E9EB",
      borderRadius: 8,
      overflow: "hidden",
      fontFamily: "'Inter', sans-serif",
    }}>
      {/* Section title */}
      {title && (
        <div style={{ padding: "16px 16px 14px", borderBottom: "1px solid #E9E9EB" }}>
          <span style={{ fontSize: 18, fontWeight: 500, color: "#080908" }}>{title}</span>
        </div>
      )}

      {/* Column headers */}
      <div style={{
        display: "grid",
        gridTemplateColumns: gridTemplate,
        borderBottom: "1px solid #E9E9EB",
        background: "#FFFFFF",
      }}>
        {columns.map((col, ci) => (
          <div key={col.key} style={{
            display: "flex", alignItems: "center", gap: 4,
            fontSize: 14, fontWeight: 500, color: "#8C8C8B",
            padding: "10px 16px",
            borderRight: ci < columns.length - 1 ? "1px solid #E9E9EB" : "none",
            justifyContent: col.align === "right" ? "flex-end" : "flex-start",
          }}>
            {col.label}
            {col.sortable && <SortIcon />}
          </div>
        ))}
      </div>

      {/* Data rows */}
      {rows.map((row, ri) => (
        <div
          key={ri}
          onClick={() => onRowClick?.(row, ri)}
          onMouseEnter={() => setHovered(ri)}
          onMouseLeave={() => setHovered(null)}
          style={{
            display: "grid",
            gridTemplateColumns: gridTemplate,
            borderBottom: ri < rows.length - 1 ? "1px solid #E9E9EB" : "none",
            background: hovered === ri ? "#FAFAFA" : "#FFFFFF",
            transition: "background 0.1s",
            cursor: onRowClick ? "pointer" : "default",
          }}
        >
          {columns.map((col, ci) => {
            const value = row[col.key];
            return (
              <div key={col.key} style={{
                display: "flex",
                alignItems: "center",
                justifyContent: col.align === "right" ? "flex-end" : "flex-start",
                fontSize: 14,
                color: "#080908",
                padding: "14px 16px",
                borderRight: ci < columns.length - 1 ? "1px solid #E9E9EB" : "none",
              }}>
                {col.render ? col.render(value, row, ri) : value}
              </div>
            );
          })}
        </div>
      ))}

      {/* Footer count */}
      {footerLabel && (
        <div style={{
          padding: "12px 16px",
          fontSize: 14,
          color: "#8C8C8B",
          borderTop: "1px solid #E9E9EB",
        }}>
          {footerLabel}
        </div>
      )}
    </div>
  );
}

// ── AccountTable ─────────────────────────────────────────────────────────────
// Specialized table for the Bank Reconciliation overview page.
// Shows bank/credit card accounts with feed balance, statement balance,
// GL balance (with difference badge), transaction matching progress,
// and contextual action buttons (Run reconciliation / suggestions / Reconciled).
//
// Props:
//   title               — string: section title (e.g. "Bank accounts")
//   rows                — array of { name, feedBalance, glBalance, glSub }
//   footerLabel         — string: footer text (e.g. "4 bank accounts")
//   onRunReconciliation — fn(accountName): called when "Run reconciliation" is clicked
//   onViewResults       — fn(accountName): called when suggestions button is clicked
//   reconciledAccounts  — Set: which accounts have been reconciled
//   reconciledData      — object: per-account data { statementBalance, difference, matched, suggestions }
export function AccountTable({ title, rows, footerLabel, onRunReconciliation, onViewResults, reconciledAccounts = new Set(), reconciledData = {} }) {
  const [hovered, setHovered] = useState(null);
  const cols = ["Account", "Feed balance", "Statement balance", "GL balance", "Tr. matching", "Actions"];
  const sortable = new Set(["Account", "Feed balance", "Statement balance", "GL balance"]);

  return (
    <div style={{ background: "#FFFFFF", border: "1px solid #E9E9EB", borderRadius: 8, overflow: "hidden" }}>
      {/* Title row */}
      <div style={{ padding: "16px 16px 14px", borderBottom: "1px solid #E9E9EB" }}>
        <span style={{ fontSize: 18, fontWeight: 500, color: "#080908" }}>{title}</span>
      </div>

      {/* Header row */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "2fr 1fr 1.1fr 1fr 0.8fr 220px",
        borderBottom: "1px solid #E9E9EB",
        background: "#FFFFFF",
      }}>
        {cols.map((col, ci) => (
          <div key={col} style={{
            display: "flex", alignItems: "center", gap: 4,
            fontSize: 14, fontWeight: 500, color: "#8C8C8B",
            padding: "10px 16px",
            borderRight: ci < cols.length - 1 ? "1px solid #E9E9EB" : "none",
          }}>
            {col}
            {sortable.has(col) && <SortIcon />}
          </div>
        ))}
      </div>

      {/* Data rows */}
      {rows.map((row, i) => {
        const isReconciled = reconciledAccounts.has(row.name);
        const rData = reconciledData[row.name] || {};

        return (
          <div
            key={i}
            onMouseEnter={() => setHovered(i)}
            onMouseLeave={() => setHovered(null)}
            style={{
              display: "grid",
              gridTemplateColumns: "2fr 1fr 1.1fr 1fr 0.8fr 220px",
              borderBottom: i < rows.length - 1 ? "1px solid #E9E9EB" : "none",
              background: hovered === i ? "#FAFAFA" : "#FFFFFF",
              transition: "background 0.1s",
            }}
          >
            {/* Account name */}
            <div style={{ display: "flex", alignItems: "center", fontSize: 14, color: "#080908", padding: "14px 16px", borderRight: "1px solid #E9E9EB" }}>{row.name}</div>

            {/* Feed balance */}
            <div style={{ display: "flex", alignItems: "center", fontSize: 14, color: "#080908", padding: "14px 16px", borderRight: "1px solid #E9E9EB" }}>{row.feedBalance}</div>

            {/* Statement balance */}
            <div style={{ display: "flex", alignItems: "center", fontSize: 14, color: isReconciled ? "#080908" : "#9D9D9E", padding: "14px 16px", borderRight: "1px solid #E9E9EB" }}>
              {isReconciled ? rData.statementBalance : "No bank statement"}
            </div>

            {/* GL balance + difference badge */}
            <div style={{ display: "flex", flexDirection: "column", justifyContent: "center", padding: "14px 16px", borderRight: "1px solid #E9E9EB" }}>
              <div style={{ fontSize: 14, color: "#080908" }}>{row.glBalance}</div>
              <span style={{
                display: "inline-block",
                background: isReconciled && rData.difference !== "£0,00" ? "#FCEFEC" : "#F5F5F5",
                border: "none",
                borderRadius: 4,
                padding: "2px 6px",
                fontSize: 11,
                fontWeight: 500,
                color: isReconciled && rData.difference !== "£0,00" ? "#C8543A" : "#8C8C8B",
                marginTop: 4,
                alignSelf: "flex-start",
              }}>{isReconciled ? rData.difference : row.glSub}</span>
            </div>

            {/* Tr. matching */}
            <div style={{ display: "flex", alignItems: "center", padding: "14px 16px", borderRight: "1px solid #E9E9EB" }}>
              {isReconciled ? (
                <span style={{
                  display: "inline-flex", alignItems: "center", gap: 5,
                  background: "#F1F8F0", border: "none",
                  borderRadius: 4, padding: "2px 8px",
                  fontSize: 12, fontWeight: 500, color: "#6BAC5B",
                }}>
                  {(() => {
                    const parts = rData.matched.split("/");
                    const pct = (parseInt(parts[0]) / parseInt(parts[1])) * 100;
                    const r = 4, circ = 2 * Math.PI * r, off = circ - (pct / 100) * circ;
                    return (
                      <svg width="12" height="12" viewBox="0 0 12 12" style={{ transform: "rotate(-90deg)", flexShrink: 0 }}>
                        <circle cx="6" cy="6" r={r} fill="none" stroke="#ACD394" strokeWidth="2" />
                        <circle cx="6" cy="6" r={r} fill="none" stroke="#05A105" strokeWidth="2"
                          strokeDasharray={`${circ} ${circ}`} strokeDashoffset={off} strokeLinecap="round" />
                      </svg>
                    );
                  })()}
                  {rData.matched}
                </span>
              ) : (
                <TrMatchBadge value="0/0" />
              )}
            </div>

            {/* Action button */}
            <div style={{ display: "flex", alignItems: "center", padding: "14px 16px" }}>
              {isReconciled && rData.suggestions > 0 ? (
                /* Post-reconciliation: suggestions button */
                <button
                  style={{
                    display: "inline-flex", alignItems: "center", gap: 6,
                    padding: "6px 12px",
                    border: "1px solid #F4CCC4",
                    borderRadius: 6,
                    background: "#FFFFFF",
                    cursor: "pointer",
                    fontSize: 14, fontWeight: 500, color: "#C8543A",
                    whiteSpace: "nowrap",
                  }}
                  onMouseEnter={e => { e.currentTarget.style.borderColor = "#C8543A"; e.currentTarget.style.background = "#FCEFEC"; }}
                  onMouseLeave={e => { e.currentTarget.style.borderColor = "#F4CCC4"; e.currentTarget.style.background = "#FFFFFF"; }}
                  onClick={() => onViewResults?.(row.name)}
                >
                  {rData.suggestions} suggestion{rData.suggestions !== 1 ? "s" : ""}
                  <svg width="16" height="16" viewBox="0 0 16 16" fill="none">
                    <circle cx="8" cy="8" r="6.5" stroke="#C8543A" strokeWidth="1" />
                    <path d="M6.5 5.8L10.8 8L6.5 10.2V5.8Z" fill="#C8543A" />
                  </svg>
                </button>
              ) : isReconciled ? (
                /* Reconciled with no suggestions */
                <span style={{
                  display: "inline-flex", alignItems: "center", gap: 6,
                  padding: "6px 12px",
                  fontSize: 14, fontWeight: 500, color: "#6BAC5B",
                }}>
                  <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                    <circle cx="7" cy="7" r="6" stroke="#6BAC5B" strokeWidth="1.25"/>
                    <path d="M4.5 7L6.2 8.7L9.5 5.3" stroke="#6BAC5B" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                  Reconciled
                </span>
              ) : (
                /* Default: Run reconciliation */
                <button
                  style={{
                    display: "inline-flex", alignItems: "center", gap: 6,
                    padding: "6px 12px",
                    border: "1px solid #E9E9EB",
                    borderRadius: 6,
                    background: "#FFFFFF",
                    cursor: "pointer",
                    fontSize: 14, fontWeight: 500, color: "#080908",
                    whiteSpace: "nowrap",
                  }}
                  onMouseEnter={e => { e.currentTarget.style.borderColor = "#CFCFD1"; e.currentTarget.style.background = "#FAFAFA"; }}
                  onMouseLeave={e => { e.currentTarget.style.borderColor = "#E9E9EB"; e.currentTarget.style.background = "#FFFFFF"; }}
                  onClick={() => onRunReconciliation?.(row.name)}
                >
                  Run reconciliation
                  <PlayCircleIcon color="#080908" />
                </button>
              )}
            </div>
          </div>
        );
      })}

      {/* Footer count */}
      <div style={{ padding: "12px 16px", fontSize: 14, color: "#8C8C8B", borderTop: "1px solid #E9E9EB" }}>
        {footerLabel}
      </div>
    </div>
  );
}
