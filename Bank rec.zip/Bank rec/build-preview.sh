#!/bin/bash
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

tail -n +2 BankReconciliation.jsx > /tmp/brec-input.jsx
./node_modules/.bin/babel /tmp/brec-input.jsx -o /tmp/brec-compiled.js

python3 - << 'PYEOF'
with open('/tmp/brec-compiled.js') as f:
    compiled = f.read()

compiled = compiled.replace('export default function BankReconciliation(', 'function BankReconciliation(', 1)

with open('node_modules/react/umd/react.development.js') as f:
    react_js = f.read()
with open('node_modules/react-dom/umd/react-dom.development.js') as f:
    reactdom_js = f.read()

html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<title>Bank Reconciliation — Full Preview</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet" />
<style>
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{ font-family: 'Inter', sans-serif; }}
  @keyframes spin {{ to {{ transform: rotate(360deg); }} }}
</style>
</head>
<body>
<div id="root"></div>
<script>
{react_js}
</script>
<script>
{reactdom_js}
</script>
<script>
const {{ useState, useEffect, useRef }} = React;
{compiled}
ReactDOM.createRoot(document.getElementById("root")).render(React.createElement(BankReconciliation));
</script>
</body>
</html>"""

with open('BankReconciliation-preview.html', 'w') as f:
    f.write(html)
print(f"Done. {len(html.splitlines())} lines.")
PYEOF
