import { useState } from "react";
import { PrimaryButton, SecondaryButton } from "./Buttons";
import { DataTable } from "./Tables";

// ── Helper icons ─────────────────────────────────────────────────────────────
function PdfIcon() {
  return (
    <svg width="14" height="16" viewBox="0 0 14 16" fill="none">
      <path d="M1 2C1 1.45 1.45 1 2 1H9L13 5V14C13 14.55 12.55 15 12 15H2C1.45 15 1 14.55 1 14V2Z" stroke="#C8543A" strokeWidth="1" fill="none"/>
      <path d="M9 1L13 5H9V1Z" fill="#FCEFEC" stroke="#C8543A" strokeWidth="0.75"/>
      <text x="2.5" y="12" fontSize="4" fill="#C8543A" fontFamily="Inter" fontWeight="600">PDF</text>
    </svg>
  );
}

function ExternalIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none">
      <path d="M2.5 9.5L9.5 2.5M9.5 2.5H5.5M9.5 2.5V6.5" stroke="white" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

function MoreIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
      <circle cx="7" cy="2.5" r="1.2" fill="#545453"/>
      <circle cx="7" cy="7" r="1.2" fill="#545453"/>
      <circle cx="7" cy="11.5" r="1.2" fill="#545453"/>
    </svg>
  );
}

function Chevron() {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
      <path d="M3 5.5L7 9.5L11 5.5" stroke="#8C8C8B" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

// ── RecommendationCard ───────────────────────────────────────────────────────
// A card for displaying a reconciliation recommendation/issue with details,
// a mini data table, and contextual action buttons.
//
// Props:
//   title           — string: card title (e.g. "Missing entry: Yorkshire Tea Estates")
//   description     — string: explanation of the issue
//   statusLabel     — string: status badge text (e.g. "Unresolved")
//   statusStyle     — object: { background, border, color } for the status badge
//   tableRow        — object: { state, contact, date, amount, email } for the mini table
//   primaryLabel    — string: label for the primary action button
//   external        — boolean: show external link icon on primary button
//   fileAction      — string|null: filename for the PDF button, or null to show "Upload document"
//   onPrimaryAction — fn(): called when primary button is clicked
//   onFileAction    — fn(): called when file/upload button is clicked
//   onIgnore        — fn(): called when "Ignore suggestion" is clicked
//   onMore          — fn(): called when the more (...) button is clicked
export default function RecommendationCard({
  title = "Missing entry",
  description = "",
  statusLabel = "Unresolved",
  statusStyle = { background: "#FDF8EE", border: "1px solid #F8E9CB", color: "#D5A750" },
  tableRow = {},
  primaryLabel = "Create spend money",
  external = false,
  fileAction = null,
  onPrimaryAction,
  onFileAction,
  onIgnore,
  onMore,
}) {
  return (
    <div style={{
      background: "#FFFFFF",
      border: "1px solid #EFF1F4",
      borderRadius: 12,
      padding: "20px",
      overflow: "hidden",
      fontFamily: "'Inter', sans-serif",
    }}>
      {/* Card header */}
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 10 }}>
        <span style={{ fontSize: 14, fontWeight: 500, color: "#080908" }}>{title}</span>
        <div style={{ display: "flex", alignItems: "center", gap: 8, flexShrink: 0, marginLeft: 12 }}>
          <span style={{
            fontSize: 12, fontWeight: 500, padding: "2px 8px", borderRadius: 4,
            background: statusStyle.background,
            border: statusStyle.border,
            color: statusStyle.color,
            whiteSpace: "nowrap",
          }}>
            {statusLabel}
          </span>
          <Chevron />
        </div>
      </div>

      {/* Description */}
      <p style={{ fontSize: 13, color: "#4F4F4F", lineHeight: "20px", margin: "0 0 14px" }}>
        {description}
      </p>

      {/* Mini table */}
      <div style={{ marginBottom: 14 }}>
        <DataTable
          columns={[
            { key: "state",   label: "State",     width: "1fr" },
            { key: "contact", label: "Contact",   width: "1.4fr" },
            { key: "date",    label: "Date",      width: "1fr" },
            { key: "amount",  label: "Amount",    width: "0.8fr" },
            { key: "email",   label: "Email b...", width: "0.9fr" },
          ]}
          rows={[tableRow]}
        />
      </div>

      {/* Actions */}
      <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
        <PrimaryButton
          style={{ padding: "7px 14px", fontSize: 13, borderRadius: 8 }}
          icon={external ? <ExternalIcon /> : undefined}
          onClick={onPrimaryAction}
        >
          {primaryLabel}
        </PrimaryButton>

        {fileAction ? (
          <SecondaryButton
            style={{ padding: "7px 12px", fontSize: 13, borderRadius: 8, borderColor: "#EFF1F4" }}
            icon={null}
            onClick={onFileAction}
          >
            <PdfIcon />{fileAction}
          </SecondaryButton>
        ) : (
          <SecondaryButton
            style={{ padding: "7px 12px", fontSize: 13, borderRadius: 8, borderColor: "#EFF1F4" }}
            onClick={onFileAction}
          >
            Upload document
          </SecondaryButton>
        )}

        <button
          style={{
            width: 32, height: 32, border: "1px solid #EFF1F4", borderRadius: 8,
            background: "#FFFFFF", cursor: "pointer",
            display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
          }}
          onMouseEnter={e => e.currentTarget.style.background = "#F5F5F5"}
          onMouseLeave={e => e.currentTarget.style.background = "#FFFFFF"}
          onClick={onMore}
        >
          <MoreIcon />
        </button>

        <div style={{ flex: 1 }} />

        <button
          style={{
            padding: "7px 12px", border: "none", borderRadius: 8,
            background: "#FCEFEC", fontSize: 13, fontWeight: 500,
            color: "#C8543A", cursor: "pointer", whiteSpace: "nowrap",
          }}
          onMouseEnter={e => e.currentTarget.style.background = "#F9E5E1"}
          onMouseLeave={e => e.currentTarget.style.background = "#FCEFEC"}
          onClick={onIgnore}
        >
          Ignore suggestion
        </button>
      </div>
    </div>
  );
}
