// ── Mimo Button Components ───────────────────────────────────────────────────
// Two button variants following the Mimo design system:
//   PrimaryButton  — green brand CTA (one per page max)
//   SecondaryButton — outlined neutral action button

// ── PrimaryButton ────────────────────────────────────────────────────────────
// Props:
//   children  — button label (text / elements)
//   icon      — optional React element rendered after the label
//   onClick   — fn(): click handler
//   disabled  — boolean: disables interaction
//   style     — object: style overrides
export function PrimaryButton({ children, icon, onClick, disabled = false, style = {} }) {
  return (
    <button
      onClick={disabled ? undefined : onClick}
      disabled={disabled}
      style={{
        display: "inline-flex", alignItems: "center", gap: 8,
        padding: "10px 16px",
        background: disabled ? "#F5F5F5" : "#05A105",
        color: disabled ? "#9D9D9E" : "#FFFFFF",
        border: "none", borderRadius: 8,
        cursor: disabled ? "default" : "pointer",
        fontSize: 14, fontWeight: 500,
        fontFamily: "'Inter', sans-serif",
        transition: "background 0.15s ease",
        ...style,
      }}
      onMouseEnter={e => { if (!disabled) e.currentTarget.style.background = "#008D00"; }}
      onMouseLeave={e => { if (!disabled) e.currentTarget.style.background = "#05A105"; }}
    >
      {children}
      {icon}
    </button>
  );
}

// ── SecondaryButton ──────────────────────────────────────────────────────────
// Props:
//   children  — button label (text / elements)
//   icon      — optional React element rendered after the label
//   onClick   — fn(): click handler
//   disabled  — boolean: disables interaction
//   style     — object: style overrides
export function SecondaryButton({ children, icon, onClick, disabled = false, style = {} }) {
  return (
    <button
      onClick={disabled ? undefined : onClick}
      disabled={disabled}
      style={{
        display: "inline-flex", alignItems: "center", gap: 6,
        padding: "6px 12px",
        background: disabled ? "#F5F5F5" : "#FFFFFF",
        color: disabled ? "#9D9D9E" : "#080908",
        border: `1px solid ${disabled ? "#F5F5F5" : "#E9E9EB"}`,
        borderRadius: 6,
        cursor: disabled ? "default" : "pointer",
        fontSize: 14, fontWeight: 500,
        fontFamily: "'Inter', sans-serif",
        whiteSpace: "nowrap",
        transition: "all 0.15s ease",
        ...style,
      }}
      onMouseEnter={e => {
        if (!disabled) {
          e.currentTarget.style.borderColor = "#CFCFD1";
          e.currentTarget.style.background = "#FAFAFA";
        }
      }}
      onMouseLeave={e => {
        if (!disabled) {
          e.currentTarget.style.borderColor = "#E9E9EB";
          e.currentTarget.style.background = "#FFFFFF";
        }
      }}
    >
      {children}
      {icon}
    </button>
  );
}
