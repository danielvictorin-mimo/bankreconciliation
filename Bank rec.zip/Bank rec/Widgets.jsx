// ── Stats Summary Widgets ────────────────────────────────────────────────────
// A row of progress cards showing high-level metrics at the top of a data page.

// ── ProgressRing (internal) ──────────────────────────────────────────────────
function ProgressRing({ progress = 0, size = 40, strokeWidth = 3 }) {
  const r = (size - strokeWidth * 2) / 2;
  const circ = 2 * Math.PI * r;
  const offset = circ - (progress / 100) * circ;
  const c = size / 2;
  return (
    <svg width={size} height={size} style={{ transform: "rotate(-90deg)", flexShrink: 0 }}>
      <circle cx={c} cy={c} r={r} fill="none" stroke="#EAF2E2" strokeWidth={strokeWidth} />
      <circle cx={c} cy={c} r={r} fill="none" stroke="#05A105" strokeWidth={strokeWidth}
        strokeDasharray={`${circ} ${circ}`} strokeDashoffset={offset} strokeLinecap="round" />
    </svg>
  );
}

// ── StatsWidget ──────────────────────────────────────────────────────────────
// Props:
//   label     — string: description text (e.g. "Bank statements received")
//   value     — string: metric text (e.g. "0 of 5 statements")
//   progress  — number 0-100: fill percentage for the progress ring
export function StatsWidget({ label, value, progress = 0 }) {
  return (
    <div style={{
      background: "#FFFFFF",
      border: "1px solid #E9E9EB",
      borderRadius: 8,
      padding: "16px 20px",
      display: "flex",
      alignItems: "center",
      gap: 12,
      fontFamily: "'Inter', sans-serif",
    }}>
      <ProgressRing progress={progress} size={40} strokeWidth={3} />
      <div>
        <div style={{ fontSize: 12, color: "#8C8C8B", marginBottom: 2 }}>{label}</div>
        <div style={{ fontSize: 16, fontWeight: 500, color: "#080908" }}>{value}</div>
      </div>
    </div>
  );
}

// ── StatsRow ─────────────────────────────────────────────────────────────────
// Renders a row of StatsWidget cards in a grid.
// Props:
//   items — array of { label, value, progress }
//   columns — number of grid columns (defaults to items.length)
export default function StatsRow({ items = [], columns }) {
  const cols = columns || items.length || 1;
  return (
    <div style={{
      display: "grid",
      gridTemplateColumns: `repeat(${cols}, 1fr)`,
      gap: 12,
    }}>
      {items.map((item, i) => (
        <StatsWidget key={i} label={item.label} value={item.value} progress={item.progress} />
      ))}
    </div>
  );
}
